﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisualStudioTips
{
    public class SomeClass
    {
        public string UsefulMethod()
        {
            return "some_changed_value";
        }
    }
}
